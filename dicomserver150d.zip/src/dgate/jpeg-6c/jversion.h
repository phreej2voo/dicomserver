/*
 * jversion.h
 *
 * Copyright (C) 1991-1998, Thomas G. Lane.
 * Modifided for multibit by Bruce Barton of BITS Limited (shameless plug), 2009, (GPL).
 * This file is part of the Independent JPEG Group's software.
 * For conditions of distribution and use, see the accompanying README file.
 *
 * This file contains software version identification.
 */


#define JVERSION	"6c 29-Jun-2009"

#define JCOPYRIGHT	"Copyright (C) 1998, Thomas G. Lane"
