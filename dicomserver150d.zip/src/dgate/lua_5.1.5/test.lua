print("Hello from ".._VERSION)
